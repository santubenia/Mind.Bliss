package com.mhss.app.preferences.di

import org.koin.core.annotation.ComponentScan
import org.koin.core.annotation.Module

@Module
@ComponentScan("com.mhss.app.preferences")
class PreferencesModule