package com.mhss.app.alarm.model


data class Alarm(
    val id: Int,
    val time: Long,
)
