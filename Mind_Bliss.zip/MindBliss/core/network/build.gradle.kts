plugins {
    alias(libs.plugins.jetbrains.kotlin.jvm)
}