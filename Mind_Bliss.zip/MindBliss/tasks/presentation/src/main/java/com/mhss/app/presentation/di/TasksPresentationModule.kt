package com.mhss.app.presentation.di

import org.koin.core.annotation.ComponentScan
import org.koin.core.annotation.Module

@Module
@ComponentScan("com.mhss.app.presentation")
class TasksPresentationModule