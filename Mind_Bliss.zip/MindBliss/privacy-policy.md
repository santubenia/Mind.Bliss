# My Brain Privacy Policy

All data is stored locally on the device and never leaves the device to any server owned by me or any 3rd party

There are no ads or trackers in the app and no data is collected.
