package com.mhss.app.domain.di

import org.koin.core.annotation.ComponentScan
import org.koin.core.annotation.Module

@Module
@ComponentScan("com.mhss.app.domain")
class DiaryDomainModule